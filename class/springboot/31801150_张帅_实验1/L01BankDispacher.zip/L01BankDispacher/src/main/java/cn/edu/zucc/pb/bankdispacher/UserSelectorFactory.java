package cn.edu.zucc.pb.bankdispacher;

import com.sun.deploy.security.SelectableSecurityManager;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

/**
 * 此类从bank.properties文件加载selector，实现用户选择算法实现的动态加载
 * 重点体会
 * 1）接口约定规范的服务
 * 2）用反射动态获取实现类实现动态性
 * @author pengbin
 * @version 1.0
 * @date 2020-02-24 16:18
 */
public class UserSelectorFactory {
    public static IUserSelector getSelector() throws IOException, ClassNotFoundException, IllegalAccessException, InstantiationException {
        //TODO 实现从配置文件 bank.properties加载selector配置项
        String selectorName = "";
        Properties properties = new Properties();
        //使用InPutStream读取配置文件
        BufferedReader bufferedReader = new BufferedReader(new FileReader( System.getProperty("user.dir")+"\\src\\main\\java\\cn\\edu\\zucc\\pb\\bankdispacher\\bank.properties"));
        properties.load(bufferedReader);
        selectorName = properties.getProperty("selector");


        //TODO 通过反射接口从上面的selectorName进行实现类创建
        IUserSelector selector = (IUserSelector) Class.forName(selectorName).newInstance();

        return selector;
    }
}
