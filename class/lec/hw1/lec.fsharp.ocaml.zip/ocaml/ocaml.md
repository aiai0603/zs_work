

## install

https://ocaml.org/docs/install.html
https://www.cs.cornell.edu/courses/cs3110/2017fa/install.html


web based
http://ocsigen.org/js_of_ocaml/2.8.4/files/toplevel/index.html