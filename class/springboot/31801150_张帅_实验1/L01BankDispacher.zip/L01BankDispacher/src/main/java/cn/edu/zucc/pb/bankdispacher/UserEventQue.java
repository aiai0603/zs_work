package cn.edu.zucc.pb.bankdispacher;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 用户排队队列
 * @author pengbin
 * @version 1.0
 * @date 2020-02-24 16:07
 */
public class UserEventQue {
    private static int SEQ = 0;

    //队列
    private List<UserEvent> events = new ArrayList<UserEvent>();

    //单例模式使用UserEventQue
    private static UserEventQue instance = new UserEventQue();
    private UserEventQue(){}
    public static UserEventQue getInstance(){
        return instance;
    }

    /**
     * 分配一个用户事件，对应比如用户在叫号机上按一下
     * @param category 来的用户类别
     * @return
     */
    public UserEvent nextUserArrive(EUserCategory category){
        UserEvent event = new UserEvent();
        event.setArriveTime(new Date());
        event.setCategory(category);
        //保证线程安全；TODO: 思考，这里为什么需要保证线程安全
        synchronized (UserEventQue.class){
            event.setSeq(SEQ++);
            System.out.println("用户"+event.getSeq()+"来了,服务类型:"+event.getCategory()+",达到时间:"+event.getArriveTime());
            events.add(event);
        }

        return event;
    }

    /**
     * 分派一个用户到窗口处理
     * @return
     */
    public UserEvent dispatchUser() throws IOException {
        //使用工厂类动态加载算法实现类
        IUserSelector selector = null;
        try {
            selector = UserSelectorFactory.getSelector();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        }

        if(selector != null){
            //保证线程安全；TODO: 思考，这里为什么需要保证线程安全
            synchronized (UserEventQue.class){
                UserEvent event = selector.select(events);
                //TODO 移除队列中选中的event


                if(event!=null)
                {
                    System.out.println("用户"+event.getSeq()+"得到了服务：服务类型："+event.getCategory().toString()+",服务时间："+new Date());
                    events.remove(event);
                    return event;
                }

            }
        }

        return null;
    }
}
