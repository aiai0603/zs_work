#!/bin/env bash

cd /koans/FSharpKoans
dotnet watch run

