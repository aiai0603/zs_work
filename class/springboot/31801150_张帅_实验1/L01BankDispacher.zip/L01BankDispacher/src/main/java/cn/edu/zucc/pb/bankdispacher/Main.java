package cn.edu.zucc.pb.bankdispacher;

import cn.edu.zucc.pb.bankdispacher.simulator.BankCounter;
import cn.edu.zucc.pb.bankdispacher.simulator.UserGenerator;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;

import javax.security.auth.login.Configuration;
import java.io.*;
import java.util.Properties;

/**
 * 主控程序，让仿真程序和实际的调度程序运行起来
 * @author pengbin
 * @version 1.0
 * @date 2020-02-24 16:54
 */
public class Main {

    public static volatile boolean exit=true;
    public static void main(String[] args) throws IOException {


        //TODO 实现从配置文件 bank.properties加载counter.count配置项
        int counterCount = 1;
        Properties properties = new Properties();
        //使用InPutStream读取配置文件
        BufferedReader bufferedReader = new BufferedReader(new FileReader( System.getProperty("user.dir")+"\\src\\main\\java\\cn\\edu\\zucc\\pb\\bankdispacher\\bank.properties"));
        properties.load(bufferedReader);
        counterCount = Integer.valueOf(properties.getProperty("counter.count"));


        //创建n个柜台，仿真银行开门
        for(int i = 0; i < counterCount; i++){
            Thread counterThread = new Thread("Counter-" + i){

                @Override
                public void run() {
                    BankCounter counter = new BankCounter();
                    try {
                        counter.start();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            };
            counterThread.start();
            System.out.println("窗口"+(i+1)+"开放了！");
        }

        //开始启动用户产生仿真
        Thread userGenerator = new Thread("UserGenerator"){
            @Override
            public void run() {
              UserGenerator generator=new UserGenerator();
              generator.start(100);
            }
        };
        userGenerator.start();

        /**TODO 如果这里什么都不做，那么主线程就退出了，上面启动的所有仿真线程还活着
            这个是不好的设计，请修改这个main方法，是否可以做到可以控制所有的仿真线程在
            仿真运行比如100个用户后可以恰当的退出
         */

        try {
            userGenerator.join();
            exit=false;
            System.out.println("100人获得服务，今日服务结束了，银行关门！");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }




    }
}
