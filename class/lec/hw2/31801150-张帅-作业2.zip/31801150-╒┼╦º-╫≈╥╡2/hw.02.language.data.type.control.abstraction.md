# 2020-21学年第2学期

## 实 验 报 告

![zucc](zucc.png){width="1.5208333333333333in" height="1.5208333333333333in"}

- 课程名称: <u>编程语言原理与编译</u>
- 实验项目: <u>类型模块与控制流</u>
- 专业班级: <u>计算1803</u>
- 学生学号: <u>31801150</u>
- 学生姓名: <u>张帅</u>
- 实验指导教师: <u>郭鸣</u>

### 实验目的

- 掌握FSharp、OCaml语言的发展历史
- 编程ML系列语言的类型系统、控制结构


### 实验内容

1.  阅读

    - plan04-1.pdf 类型，理解下面的概念
      -   类型推理
      -   类型检查
      -   类型相容

    - plan07.pdf 模块
      -   模块组织
      -   模块接口定义

1. 学习 F#/OCaml 语言 
   
    - 参考[lec.fsharp.ocaml.zip](https://bb.zucc.edu.cn/bbcswebdav/users/j04014/PLC/backup/lec.fsharp.ocaml.zip)
    - 参考 [F#入门](http://sigcc.gitee.io/plc2021/#/02/fsharp)
      - code/lecture.fs 通读理解后，运行代码
      
        ![1](\img\1.png)
      
      - FSharpKoans-fsharp 项目
        - 进入`FSharpKoans-fsharp/FSharpKoans` directory and run `dotnet watch run`
        
        - 参考程序运行的提示，修改对应代码，完成公案 FSharpKoans
        
          ![image-20210317161209778](\img\2.png)
      
    - 教材p3 1.3 直线式程序解释器 straight_line_program_interpreter.ml 理解解释器（自选）
      - 中文版C语言程序有些晦涩，参考[Modern.compiler.implementation.in.ML.pdf](https://bb.zucc.edu.cn/bbcswebdav/users/j04014/PLC/book/Modern.compiler.implementation.in.ML.pdf) 
      - 将代码迁移到 F#（自选）
    
1. 用F#/OCaml完成 教材习题
   
      首先使用F#将书本上的c代码进行复现
  
      ```F#
      type 'a bst = NL | BinTree of  'a bst * 'a * 'a bst;;
      
      let Leaf = NL;;
      
      let rec insert (key,t) =
          match t with
          | NL ->  BinTree(Leaf, key, Leaf)   
          | BinTree(left ,k ,right) -> 
              if key<k then  BinTree( insert(key,left), k, right)
              else  if key>k then  BinTree(left, k, insert(key,right) )
              else  BinTree(left ,k ,right)
      
      let mytree = NL
      let myta=insert(2, mytree);;
      let mytb=insert(1, myta);;
      let mytc=insert(4, mytb);;
      
      ```
      
      ![image-20210318195733735](\img\3.png)
      
      - p9 1.1 a b
      
        a：
      
        ```F#
        let rec myMember(key, t) =
            match t with
            | NL -> false
            | BinTree(left ,k ,right) -> 
                if key = k then true
                else if key < k then myMember(key, left)
                else myMember(key, right);;
        ```
      
        ![image-20210318191749268](\img\4.png)
      
        b:
      
        ```F#
        type 'a bst = NL | BinTree of  'a bst * 'a * 'a bst;;
        
        let Leaf = NL;;
        
        let rec insert (key,bind,t) =
            
            match t with
            | NL ->    bind := BinTree(Leaf, key, Leaf)
                       BinTree(Leaf, key, Leaf)
            | BinTree(left ,k ,right) -> 
                if key<k then  BinTree( insert(key,bind,left), k, right)            
                else  if key>k then  BinTree(left, k, insert(key,bind,right) )
                else  bind := t
                      BinTree(left ,k ,right);;
        
        let mytree = NL;;
        
        let bindTree =  ref mytree<int> ;;
        
        let myta=insert(2,bindTree , mytree);;
        bindTree;;
        let mytb=insert(1, bindTree , myta);;
        bindTree;;
        let mytc=insert(4, bindTree , mytb);;
        bindTree;;
        
        
        
        let rec myMember(key, t) =
            match t with
            | NL -> NL
            | BinTree(left ,k ,right) -> 
                if key = k then t
                else if key < k then myMember(key, left)
                else myMember(key, right);;
        
         myMember(2,mytc);;
         myMember(3,mytc);;
            
        ```
      
        ![image-20210318215011336](\img\5.png)
      
        ![image-20210318215047672](\img\6.png)
      
      - 选做 p9 1.1 c d
      
        c
        
        ![image-20210318215900419](\img\7.png)
        
        ![image-20210318215952317](\img\8.png)
        
        d
        
        Map: 这是F#不可变类型.它是基于AVL树(平衡二叉树)实现的,它是一个完全不同的具有不同性能特征和用例的数据结构.
        
        
      
1. 在你会的语言中 ，如`C Java Python `里面 是如何实现模块机制的，请列出相关的代码说明，至少1种语言。

      ​	Erlang语言的代码是写到文件中参与编译的。其使用 Module （模块）组织。一个 Module 包含了一组函数，调用一个函数的时候，要这么调用：`Module:Function(arg1, arg2)`。或者先 `import` 某个 Module 里的函数，然后用省略Module名的方式调用：`Function(arg1, arg2)`。Module 可也提供代码管理的作用，加载一个 Module 到 Erlang VM就加载了那个 Module 里的所有代码，当想热更新代码的话，直接更新这个 Module 即可。

      ​	定义一个模块时，创建一个erl格式的文件，在文件的第一行, 用 -module(name) 来声明的 module的名字。之后第二行使用export([name/2, name/3])函数决定导出的函数，格式为函数名/函数参数个数。没导出的函数在 Module 外是无法访问的。示例如下：

      ```Erlang
      -module(first).
      -export([add/2, add/3]). 
      add(A, B) ->
      A + B.
      add(A, B, C) ->
      A + B + C.
      ```

      在模块编写完成后，使用c(name)命令对指定name的erl文件进行编译，生成.bean文件，此时在同一目录下即可调用对应module的函数

      ```Erlang
      5> c(first).
      {ok,first}
      6> first:add(1,2).
      3
      ```

