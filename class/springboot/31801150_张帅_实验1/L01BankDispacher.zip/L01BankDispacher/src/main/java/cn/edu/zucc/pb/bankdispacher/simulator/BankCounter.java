package cn.edu.zucc.pb.bankdispacher.simulator;

import cn.edu.zucc.pb.bankdispacher.EUserCategory;
import cn.edu.zucc.pb.bankdispacher.Main;
import cn.edu.zucc.pb.bankdispacher.UserEvent;
import cn.edu.zucc.pb.bankdispacher.UserEventQue;
import org.apache.commons.lang3.RandomUtils;

import java.io.IOException;
import java.util.Date;

/**
 * 银行柜台办理业务仿真程序
 * @author pengbin
 * @version 1.0
 * @date 2020-02-24 16:49
 */
public class BankCounter {
    /**
     * 模拟柜台开始办理业务
     */


    public void start() throws IOException {


        //while(true)柜台一直不下班
        while(Main.exit){
            UserEvent userEvent = UserEventQue.getInstance().dispatchUser();
            if(userEvent!=null){
                //等待一点时间,模拟在办理或者等待
                //TODO 实现不同业务类型等待不同时间

                EUserCategory type=userEvent.getCategory();


                if(type==EUserCategory.VIP) {
                    waitSomeTime();
                }
                else if(type==EUserCategory.PRIVATE){
                    for(int i=0;i<2;i++){
                        waitSomeTime();
                    }
                } else {
                    for(int i=0;i<3;i++){
                        waitSomeTime();
                    }
                }

                System.out.println("用户"+userEvent.getSeq()+"离开了,离开时间："+new Date());
            }

        }


    }

    private void waitSomeTime(){
        //随机2秒到12秒之间
        try {
            Thread.sleep(RandomUtils.nextInt(100, 12000));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return;
    }

}
