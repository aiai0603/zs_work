type 'a bst = NL | BinTree of  'a bst * 'a * 'a bst;;

let Leaf = NL;;

let rec insert (key, t) =
    match t with
    | NL -> BinTree(Leaf, key, Leaf)
    | BinTree(left ,k ,right) -> 
        if key<k then  BinTree( insert(key,left), key, right)
        else   BinTree(left, key, insert(key,right) );;
    
let mytree = insert(2,Leaf);;

let rec myMember(key, t) =
    match t with
    | NL -> false
    | BinTree(left ,k ,right) -> 
        if key = k then true
        else if key < k then myMember(key, left)
        else myMember(key, right);;

 myMember(2,mytree);;
 myMember(3,mytree);;
    




