type 'a bst = NL | BinTree of  'a bst * 'a * 'a bst;;

let Leaf = NL;;

let rec insert (key,bind,t) =
    
    match t with
    | NL ->    bind := BinTree(Leaf, key, Leaf)
               BinTree(Leaf, key, Leaf)
    | BinTree(left ,k ,right) -> 
        if key<k then  BinTree( insert(key,bind,left), k, right)            
        else  if key>k then  BinTree(left, k, insert(key,bind,right) )
        else  bind := t
              BinTree(left ,k ,right);;

let mytree = NL;;
let bindTree =  ref mytree<char> ;;
let myta=insert(2,bindTree , mytree);;
let mytb=insert(1, bindTree , myta);;
let mytc=insert(4, bindTree , mytb);;




let rec myMember(key, t) =
    match t with
    | NL -> NL
    | BinTree(left ,k ,right) -> 
        if key = k then t
        else if key < k then myMember(key, left)
        else myMember(key, right);;

 myMember(2,mytc);;
 myMember(3,mytc);;
    




